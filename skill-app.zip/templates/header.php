<?php
session_start();

include("include.php");

if (!isset($_SESSION['username'])) {
    header("location:login.php");
}
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="dark">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <!--<script src="https://kit.fontawesome.com/ae360af17e.js" crossorigin="anonymous"></script>-->
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <div class="wrapper">
        <aside id="sidebar" class="js-sidebar">
            <!-- Content For Sidebar -->
            <div class="h-100">
                <div class="sidebar-logo">
                     <a href="/" class=""><img src="image/logo.png" alt=""></a>
                </div>
                <ul class="sidebar-nav">
                    <!-- <li class="sidebar-item">
                        <a href="#" class="sidebar-link">
                            <i class="fa-solid fa-list pe-2"></i>
                            Dashboard
                        </a>
                    </li> -->
                    <li class="sidebar-item">
                        <!-- <a href="#" class="sidebar-link">
                            <i class="fa-solid fa-file-lines pe-2"></i>
                            Admission
                        </a> -->
                        <a href="/index.php" class="sidebar-link">
                            <i class="fa-solid fa-file-lines pe-2"></i>
                            Admission Form
                        </a>
                        <a href="/registration.php" class="sidebar-link">
                            <i class="fa-solid fa-file-lines pe-2"></i>
                            Registration Form
                        </a>
                        <a href="#" class="sidebar-link">
                            <i class="fa-solid fa-person-chalkboard pe-2"></i>
                            Course Module
                        </a>
                        <a href="#" class="sidebar-link">
                            <i class="fa-solid fa-circle-exclamation pe-2"></i>
                            Notice
                        </a>
                        
                    </li>

                    <!-- <li class="sidebar-item">
                        <a href="#" class="sidebar-link collapsed" data-bs-target="#auth" data-bs-toggle="collapse"
                            aria-expanded="false"><i class="fa-regular fa-user pe-2"></i>
                            Auth
                        </a>
                        <ul id="auth" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#sidebar">
                            <li class="sidebar-item">
                                <a href="./login.php" class="sidebar-link">Login</a>
                            </li>
                            <li class="sidebar-item">
                                <a href="#" class="sidebar-link">Register</a>
                            </li>

                        </ul>
                    </li> -->
                </ul>
            </div>
        </aside>

        <div class="main">
            <nav class="navbar navbar-expand px-3 border-bottom">
                <button class="btn" id="sidebar-toggle" type="button">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="navbar-collapse navbar">
                    <ul class="navbar-nav">
                        <li class="nav-item dropdown">
                            <a href="#" data-bs-toggle="dropdown" class="nav-icon pe-md-0">
                                <img src="image/imab.png" class="avatar img-fluid rounded" alt="">
                            </a>
                            <div class="dropdown-menu dropdown-menu-end">
                                <a href="#" class="dropdown-item">Profile</a>
                                <a href="./logout.php" class="dropdown-item">Logout</a>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
            <main class="content px-3 py-2">
                <div class="container-fluid">