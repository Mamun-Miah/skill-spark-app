<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="style.css">
    <title>Admission Form</title>
</head>

<body>
    <div class="mt-5">
        <div class="mb-3">
            <!--<a href="#" class="text-decoration-none p-2" style="font-size: 18px; Color: yellow; background: blue; border-radius: 10px;">Home</a>-->
        </div>

        <div class="row">
            <div class="col-md-2 justify-content-left align-self-center">
                <img class="img0" src="image/logo.png" alt="">
            </div>
            <div class="col-md-5"></div>
            <div class="col-md-5 d-flex justify-content-center align-self-center text-right">
                <p class="photo">Attached photo here..</p>
            </div>
            <!-- <div class="col-md-5 img-passport">
                <img class="img1" src="https://placehold.co/300x350" alt="">
            </div> -->
        </div>

        <h2 class="text-center mb-4">Admission Form</h2>

        <form action="../process.php" method="post" class="">
            <!-- Personal Information -->
            <div class="box rounded-3 p-4 mb-3">
                <h3 class="text-center mb-3">Please Fill Out The Required Information</h3>
                <div class="row g-3">
                    <div class="col-md-6 ">
                        <label for="date-input" class="form-label" name="admitdate">Date of Admission</label>
                        <input type="date" class="form-control" name="admitdate" id="date-input" required>
                    </div>

                    <div class="col-md-6 ">
                        <label for="course-select" class="form-label">Course</label>
                        <select class="form-select" name="course" id="course-select" aria-label="Select Course" required>
                            <option selected>Please Select Your Course</option>
                            <option value="1">Digital Marketing</option>
                            <option value="2">Web Design & Development</option>
                            <option value="3">AI: Machine Learning & Deep Learning</option>
                            <option value="4">AR/VR Applications & Game Development</option>
                            <option value="5">Computer Science Pathway</option>
                        </select>
                    </div>


                    <div class="col-md-6">
                        <label for="inputNameEnglish" class="form-label">Full Name (English)</label>
                        <input type="text" name="studentenname" class="form-control" id="inputNameEnglish" required>
                    </div>

                    <div class="col-md-6">
                        <label for="inputNameBangla" class="form-label">Full Name (Bangla)</label>
                        <input type="text" name="studentbnname" class="form-control" id="inputNameBangla" required>
                    </div>
                    <div class="col-md-6">
                        <label for="inputFathersName" class="form-label">Father's Name</label>
                        <input type="text" name="fathersname" class="form-control" id="inputFathersName" required>
                    </div>
                    <div class="col-md-6">
                        <label for="inputMothersName" class="form-label">Mother's Name</label>
                        <input type="text" name="mothersname" class="form-control" id="inputMothersName" required>
                    </div>
                </div>

                <div class="row g-3">
                    <div class="col-md-6">
                        <label for="date-input-birth" class="form-label">Date of Birth</label>
                        <input type="date" class="form-control" name="dateofbirth" id="date-input-birth" required>
                    </div>
                    <div class="col-md-6">
                        <label for="gender-select" class="form-label">Gender</label>
                        <select class="form-select" name="gender" id="gender-select" aria-label="Select Gender" required>
                            <option selected>Please Select Your Gender</option>
                            <option value="1">Male</option>
                            <option value="2">Female</option>
                            <option value="3">Others</option>
                        </select>
                    </div>
                </div>


            </div>

            <!-- Contact Information -->
            <div class="box rounded-3 p-4 mb-3">
                <h3 class="text-center">Contact Information</h3>
                <div class="row g-3">
                    <div class="col-md-6">
                        <label for="inputAddress" class="form-label">Address</label>
                        <input type="text" name="address" class="form-control" id="inputAddress" required>
                    </div>
                    <div class="col-md-6">
                        <label for="inputEmail" class="form-label">Email</label>
                        <input type="email" name="email" class="form-control" id="inputEmail" placeholder="name@example.com" required>
                    </div>
                    <div class="col-md-6">
                        <label for="inputPhone" class="form-label">Phone No.</label>
                        <input type="tel" name="phone" class="form-control" id="inputPhone" required>
                    </div>
                    <div class="col-md-6">
                        <label for="inputPhone" class="form-label">WhatsApp No.</label>
                        <input type="tel" name="whatsapp" class="form-control" id="inputPhone" required>
                    </div>

                </div>
            </div>

            <!-- Official Information -->
            <div class="box rounded-3 p-4 mb-3">
                <h3 class="text-center mb-3">Official Information</h3>
                <div class="row g-3">
                    <div class="col-md-6">
                        <label for="inputOccupation" class="form-label">Occupation</label>
                        <input type="text" name="occupation" class="form-control" id="inputOccupation" required>
                    </div>
                    <div class="col-md-6">
                        <label for="inputQualification" class="form-label">Education Qualification</label>
                        <input type="text" name="education" class="form-control" id="inputQualification" required>
                    </div>
                    <div class="col-md-6">
                        <label for="source-select" class="form-label">How did you come to know about us</label>
                        <select class="form-select" name="refer" id="source-select" aria-label="Select Source" required>
                            <option selected>Google</option>
                            <option value="1">Facebook</option>
                            <option value="2">Instagram</option>
                            <option value="3">Email</option>
                            <option value="4">Some Website</option>
                            <option value="5">Friends/Colleague</option>
                            <option value="6">Others</option>
                        </select>
                    </div>
                </div>
            </div>

            <!-- Disclaimer -->

            <div class="card box rounded-3 p-4 mb-3">
                <div class="card-body">
                    <h5 class="card-title">Disclaimer</h5>
                    <p class="card-text">I shall abide by the academic and administrative rules and regulations of Skill Spark Academy. By filling up this form, I certify that to the best of my knowledge and belief, the information provided in this application form is true and complete.</p>
                    <p class="card-text">Our website address is: <a class="link-opacity-50-hover" href="#">www.mapleitfirm.com</a></p>
                    <div class="form-check form-check-inline mb-3">
                        <input class="form-check-input" type="checkbox" id="inlineCheckbox1" value="option1" required>
                        <label class="form-check-label" for="inlineCheckbox1"> I agree to enrollment terms and condition.</label>
                    </div>

                </div>
                <div>
                    <button class="btn" type="submit" name="submit">Enroll Now</button>
                </div>
            </div>

        </form>
    </div>
</body>

</html>