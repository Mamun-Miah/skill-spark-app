<?php
if (isset($_POST["submit"])) {
    include("./include.php");

    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $admitdate = mysqli_real_escape_string($conn, $_POST["admitdate"]);
    $course = mysqli_real_escape_string($conn, $_POST["course"]);
    $studentenname = mysqli_real_escape_string($conn, $_POST["studentenname"]);
    $studentbnname = mysqli_real_escape_string($conn, $_POST["studentbnname"]);
    $fathersname = mysqli_real_escape_string($conn, $_POST["fathersname"]);
    $mothersname = mysqli_real_escape_string($conn, $_POST["mothersname"]);
    $dateofbirth = mysqli_real_escape_string($conn, $_POST["dateofbirth"]);
    $gender = mysqli_real_escape_string($conn, $_POST["gender"]);
    $address = mysqli_real_escape_string($conn, $_POST["address"]);
    $email = mysqli_real_escape_string($conn, $_POST["email"]);
    $phone = mysqli_real_escape_string($conn, $_POST["phone"]);
    $whatsapp = mysqli_real_escape_string($conn, $_POST["whatsapp"]);
    $occupation = mysqli_real_escape_string($conn, $_POST["occupation"]);
    $education = mysqli_real_escape_string($conn, $_POST["education"]);
    $refer = mysqli_real_escape_string($conn, $_POST["refer"]);

    $sqlinsert = "INSERT INTO `admitform` (`id`, `admitdate`, `course`, `studentenname`, `studentbnname`, `fathersname`, `mothersname`, `dateofbirth`, `gender`, `address`, `email`, `phone`, `whatsapp`, `occupation`, `education`, `refer`) VALUES (NULL,'$admitdate', '$course', '$studentenname', '$studentbnname', '$fathersname', '$mothersname', '$dateofbirth', '$gender', '$address', '$email', '$phone', '$whatsapp', '$occupation', '$education', '$refer')";

    if (mysqli_query($conn, $sqlinsert)) {
        echo "Record added successfully";
    } else {
        echo "Error: " . $sqlinsert . "<br>" . mysqli_error($conn);
    }

    mysqli_close($conn);
}
?>

