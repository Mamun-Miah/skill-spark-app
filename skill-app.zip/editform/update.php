<?php
if (isset($_POST["update"])) {
    include("../include.php");

    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $admitdate = mysqli_real_escape_string($conn, $_POST["admitdate"]);
    $course = mysqli_real_escape_string($conn, $_POST["course"]);
    $studentenname = mysqli_real_escape_string($conn, $_POST["studentenname"]);
    $studentbnname = mysqli_real_escape_string($conn, $_POST["studentbnname"]);
    $fathersname = mysqli_real_escape_string($conn, $_POST["fathersname"]);
    $mothersname = mysqli_real_escape_string($conn, $_POST["mothersname"]);
    $dateofbirth = mysqli_real_escape_string($conn, $_POST["dateofbirth"]);
    $gender = mysqli_real_escape_string($conn, $_POST["gender"]);
    $address = mysqli_real_escape_string($conn, $_POST["address"]);
    $email = mysqli_real_escape_string($conn, $_POST["email"]);
    $phone = mysqli_real_escape_string($conn, $_POST["phone"]);
    $whatsapp = mysqli_real_escape_string($conn, $_POST["whatsapp"]);
    $occupation = mysqli_real_escape_string($conn, $_POST["occupation"]);
    $education = mysqli_real_escape_string($conn, $_POST["education"]);
    $refer = mysqli_real_escape_string($conn, $_POST["refer"]);
    $id = mysqli_real_escape_string($conn, $_POST["id"]);

    // $sqlinsert = "INSERT INTO `admitform` (`id`, `admitdate`, `course`, `studentenname`, `studentbnname`, `fathersname`, `mothersname`, `dateofbirth`, `gender`, `address`, `email`, `phone`, `whatsapp`, `occupation`, `education`, `refer`) VALUES (NULL,'$admitdate', '$course', '$studentenname', '$studentbnname', '$fathersname', '$mothersname', '$dateofbirth', '$gender', '$address', '$email', '$phone', '$whatsapp', '$occupation', '$education', '$refer')";

    // $sqliupdate = "UPDATE admitform SET admitdate= '$admitdate', course = '$course', studentenname = '$studentenname', studentbnnam ='$studentbnname', fathersname ='$fathersname', mothersname ='$mothersname', dateofbirth ='$dateofbirth', gender = '$gender', address ='$address', email ='$email', phone ='$phone', whatsapp ='$whatsapp', occupation ='$occupation', education ='$education', refer = '$refer' WHERE id = $id";

    $sqliupdate = "UPDATE admitform SET 
    admitdate = '$admitdate', 
    course = '$course', 
    studentenname = '$studentenname', 
    studentbnname = '$studentbnname', 
    fathersname = '$fathersname', 
    mothersname = '$mothersname', 
    dateofbirth = '$dateofbirth', 
    gender = '$gender', 
    address = '$address', 
    email = '$email', 
    phone = '$phone', 
    whatsapp = '$whatsapp', 
    occupation = '$occupation', 
    education = '$education', 
    refer = '$refer' 
    WHERE id = '$id'";

    if (mysqli_query($conn, $sqliupdate)) {
        echo "Record added successfully";
    } else {
        echo "Error: " . $sqliupdate . "<br>" . mysqli_error($conn);
    }

    mysqli_close($conn);
}
?>