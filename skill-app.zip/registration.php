<?php include("./templates/header.php"); ?>
        
                    <div class="mb-3">
                        <h2>Registration</h2>
                    </div>
                   
                      
                    <div class="">
                        <div class=" ">
                            <div class="row w">
                                <div> 
                                    <a href="/creatform/registration-form.php"><button class="btn btn-success btn-sm">Create</button></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                      
                       
                    



                    <!-- Table Element -->
                 <div class="container mt-4">
    <h4 class="text-center">Registration Information</h4>
    <div class="card border-0">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead class="text-center">
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Student Name</th>
                            <th scope="col">Phone Number</th>
                            <th scope="col">Date</th>
                            <th scope="col">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                                <?php
                                include("./include.php");
                                $sqlView = "SELECT * FROM registration";
                                $result = mysqli_query($conn, $sqlView);
                                while ($data = mysqli_fetch_array($result)) {
                                    ?>
                                    <tr>

                                        <td><?php echo $data["id"]?></td>
                                        <td><?php echo $data["studentenname"]?></td>
                                        <td><?php echo $data["phone"]?></td>
                                        <td><?php echo $data["admitdate"]?></td>
                                        <td class="text-center">
                                            <a href="./view/registration.php?id=<?php echo $data["id"]?>"><button class="btn btn-success btn-sm">View</button></a>
                                            <!--<a href="./editform/edit.php?id=<?php echo $data["id"]?>"><button class="btn btn-warning btn-sm">Edit</button></a>-->
                                            <!--<a href="./templates/delete.php?id=<?php echo $data["id"]?>"><button class="btn btn-danger btn-sm">Delete</button></a>-->
                                        </td>
                                    <?php
                                }
                            ?>
                        

                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

                    



                </div>
            </main>
<?php include("./templates/footer.php"); ?>
