<?php
session_start();

include("include.php");

if (!isset($_SESSION['username'])) {
    header("location: ../login.php");
}
?>
<?php 
    $id = $_GET["id"];
    include("./include.php");
    $sqlview = "SELECT * FROM `registration` WHERE $id = id";
    $result = mysqli_query($conn, $sqlview);
    $data = mysqli_fetch_array($result);
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="style.css">
    <title>Admission Form</title>
</head>
<body>
    <div class="mt-5">

        <div class="row">
            <div class="col-md-2 justify-content-left align-self-center">      
                <img class="img0" src="image/logo.png" alt="">
            </div>
            <div class="col-md-5"></div>
            <div class="col-md-5 d-flex justify-content-center align-self-center text-right">
                <p class="photo">Attached photo here..</p>
            </div>
            <!-- <div class="col-md-5 img-passport">
                <img class="img1" src="https://placehold.co/300x350" alt="">
            </div> -->
        </div>

        <h2 class="text-center mb-4">Admission Form</h2>

        <form class="">
            <!-- Personal Information -->
            <div class="box rounded-3 p-4 mb-3">
                <h3 class="text-center mb-3">Please Fill Out The Required Information</h3>
                <div class="row g-3">
                <div class="col-md-6 ">
                    <label for="date-input" class="form-label">Date of Admission</label>
                    <input type="text" class="form-control" name="admitdate" id="date-input" value="<?php echo $data["admitdate"]?>" required>
                </div>

                <div class="col-md-6 ">
                    <label for="course-select" class="form-label">Course</label>
                    <select class="form-select" id="course-select" aria-label="Select Course" required>
                        <option value="1" <?php echo ($data["course"] == 1) ? 'selected' : ''; ?>>Digital Marketing</option>
                        <option value="2" <?php echo ($data["course"] == 2) ? 'selected' : ''; ?>>Web Design & Development</option>
                        <option value="3" <?php echo ($data["course"] == 3) ? 'selected' : ''; ?>>AI: Machine Learning & Deep Learning</option>
                        <option value="4" <?php echo ($data["course"] == 4) ? 'selected' : ''; ?>>AR/VR Applications & Game Development</option>
                        <option value="5" <?php echo ($data["course"] == 5) ? 'selected' : ''; ?>>Computer Science Pathway</option>
                    </select>
                </div>

               
                    <div class="col-md-6">
                        <label for="inputNameEnglish" class="form-label">Full Name (English)</label>
                        <input type="text" class="form-control" value="<?php echo $data["studentenname"]?>" id="inputNameEnglish" required>
                    </div>

                    <div class="col-md-6">
                        <label for="inputNameBangla" class="form-label">Full Name (Bangla)</label>
                        <input type="text" class="form-control" value="<?php echo $data["studentbnname"]?>" id="inputNameBangla" required>
                    </div>
                    <div class="col-md-6">
                        <label for="inputFathersName" class="form-label">Father's Name</label>
                        <input type="text" class="form-control" value="<?php echo $data["fathersname"]?>" id="inputFathersName" required>
                    </div>
                    <div class="col-md-6">
                        <label for="inputMothersName" class="form-label">Mother's Name</label>
                        <input type="text" class="form-control" value="<?php echo $data["mothersname"]?>" id="inputMothersName" required>
                    </div>
                </div>

                <div class="row g-3">
                    <div class="col-md-6">
                        <label for="date-input-birth" class="form-label">Date of Birth</label>
                        <input type="text" class="form-control" value="<?php echo $data["dateofbirth"]?>" name="date" id="date-input-birth" required>
                    </div>
                    <div class="col-md-6">
                        <label for="gender-select" class="form-label">Gender</label>
                        <select class="form-select" id="gender-select" aria-label="Select Gender" required>
                            <option selected>Please Select Your Gender</option>
                            <option value="1" <?php echo ($data["gender"] == 1) ? 'selected' : ''; ?>>Male</option>
                            <option value="2" <?php echo ($data["gender"] == 2) ? 'selected' : ''; ?>>Female</option>
                            <option value="3" <?php echo ($data["gender"] == 3) ? 'selected' : ''; ?>>Others</option>
                        </select>
                    </div>
                </div>


            </div>

            <!-- Contact Information -->
            <div class="box rounded-3 p-4 mb-3">
                <h3 class="text-center">Contact Information</h3>
                <div class="row g-3">
                    <div class="col-md-6">
                        <label for="inputAddress" class="form-label">Address</label>
                        <input type="text" class="form-control" value="<?php echo $data["address"]?>" id="inputAddress" required>
                    </div>
                    <div class="col-md-6">
                        <label for="inputEmail" class="form-label">Email</label>
                        <input type="email" class="form-control" value="<?php echo $data["email"]?>" id="inputEmail" placeholder="name@example.com" required>
                    </div>
                    <div class="col-md-6">
                        <label for="inputPhone" class="form-label">Phone No.</label>
                        <input type="tel" class="form-control" value="<?php echo $data["phone"]?>" id="inputPhone" required>
                    </div>
                    <div class="col-md-6">
                        <label for="inputPhone" class="form-label">WhatsApp No.</label>
                        <input type="tel" class="form-control" value="<?php echo $data["whatsapp"]?>" id="inputPhone" required>
                    </div>

                </div>
            </div>

            <!-- Official Information -->
            <div class="box rounded-3 p-4 mb-3">
                <h3 class="text-center mb-3">Official Information</h3>
                <div class="row g-3">
                    <div class="col-md-6">
                        <label for="inputOccupation" class="form-label">Occupation</label>
                        <input type="text" class="form-control" value="<?php echo $data["occupation"]?>" id="inputOccupation" required>
                    </div>
                    <div class="col-md-6">
                        <label for="inputQualification" class="form-label">Qualification</label>
                        <input type="text" class="form-control" value="<?php echo $data["education"]?>" id="inputQualification" required>
                    </div>
                    <div class="col-md-6">
                        <label for="source-select" class="form-label">How did you come to know about us</label>
                        <select class="form-select" id="source-select" aria-label="Select Source" required>
                            <option selected>Google</option>
                            <option value="1" <?php echo ($data["refer"] == 1) ? 'selected' : ''; ?>>Facebook</option>
                            <option value="2" <?php echo ($data["refer"] == 2) ? 'selected' : ''; ?>>Instagram</option>
                            <option value="3" <?php echo ($data["refer"] == 3) ? 'selected' : ''; ?>>Email</option>
                            <option value="4" <?php echo ($data["refer"] == 4) ? 'selected' : ''; ?>>Some Website</option>
                            <option value="5" <?php echo ($data["refer"] == 5) ? 'selected' : ''; ?>>Friends/Colleague</option>
                            <option value="6" <?php echo ($data["refer"] == 6) ? 'selected' : ''; ?>>Others</option>
                        </select>
                    </div>
                     <div class="col-md-6">
                        <label for="source-select" class="form-label">Schedule</label>
                        <select class="form-select" name="schedule" id="source-select" aria-label="Select Source" required>
                            <option selected>Select Schedule</option>
                            <option value="1" <?php echo ($data["schedule"] == 1) ? 'selected' : ''; ?>>Friday 16 August 4.00PM-5.30PM</option>
                            <option value="2" <?php echo ($data["schedule"] == 2) ? 'selected' : ''; ?>>Friday 16 August 5.30PM-7.00PM</option>
                            <option value="3" <?php echo ($data["schedule"] == 3) ? 'selected' : ''; ?>>Saturday 17 August 4.00PM-5.30PM</option>
                            <option value="4" <?php echo ($data["schedule"] == 4) ? 'selected' : ''; ?>>Saturday 17 August 5.30PM-7.00PM</option>
                            <option value="5" <?php echo ($data["schedule"] == 5) ? 'selected' : ''; ?>>Friday 23 August 4.00PM-5.30PM</option>
                            <option value="6" <?php echo ($data["schedule"] == 6) ? 'selected' : ''; ?>>Friday 23 August 5.30PM-7.00PM</option>
                            <option value="7" <?php echo ($data["schedule"] == 7) ? 'selected' : ''; ?>>Saturday 24 August 4.00PM-5.30PM</option>
                            <option value="8" <?php echo ($data["schedule"] == 8) ? 'selected' : ''; ?>>Saturday 24 August 5.30PM-7.00PM</option>
                            <option value="9" <?php echo ($data["schedule"] == 9) ? 'selected' : ''; ?>>Friday 30 August 4.00PM-5.30PM</option>
                            <option value="10" <?php echo ($data["schedule"] == 10) ? 'selected' : ''; ?>>Friday 30 August 5.30PM-7.00PM</option>
                            <option value="11" <?php echo ($data["schedule"] == 11) ? 'selected' : ''; ?>>Saturday 31 August 4.00PM-5.30PM</option>
                            <option value="12" <?php echo ($data["schedule"] == 12) ? 'selected' : ''; ?>>Saturday 31 August 5.30PM-7.00PM</option>
                        </select>
                    </div>
                </div>
            </div>

            <!-- Disclaimer -->
          
                <div class="card box rounded-3 p-4 mb-3">
                    <div class="card-body">
                        <h5 class="card-title">Disclaimer</h5>
                        <p class="card-text">I shall abide by the academic and administrative rules and regulations of Skill Spark Academy. By filling up this form, I certify that to the best of my knowledge and belief, the information provided in this application form is true and complete.</p>
                        <p class="card-text">Our website address is: <a class="link-opacity-50-hover" href="#">www.mapleitfirm.com</a></p>
                        <div class="form-check form-check-inline mb-3">
                            <input class="form-check-input" type="checkbox" id="inlineCheckbox1" value="option1" required>
                            <label class="form-check-label" for="inlineCheckbox1" > I agree to enrollment terms and condition.</label>
                          </div>                        
                    
                    </div>
                    <div>
                        <button class="btn" type="button">Enroll Now</button>
                      </div>
                </div>

        </form>
    </div>
</body>

</html>
