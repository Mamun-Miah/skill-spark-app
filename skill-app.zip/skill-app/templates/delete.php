<?php 
    $id = $_GET["id"];
    include("../include.php");
    $sqlview = "DELETE FROM `admitform` WHERE $id = id";
    if (mysqli_query($conn, $sqlview)) {
        echo ("Deleted");
    }
 ?>