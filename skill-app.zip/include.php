<?php
$servername = "localhost";
$username = "u462528435_Skillspark";
$password = "@Skillspark123";
$dbname = "u462528435_Skillspark";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
?>